var buff1=0;
var buff2=0;
var buff3=0;
function ajaxrequestmobile10(php_file, tagID) {          
			var request =  get_XmlHttp();	
			var lat="";
			var long1="";
			var connecion_type=checkConnection();
			var operatorname="";
			var rssi="";
			var cellid="";
			var lac="";
			var b1=""+buff1;
			var b2=""+buff2;
			var b3=""+buff3;
  navigator.geolocation.getCurrentPosition(onSuccess2, onError2);
			function onSuccess2(position) {
			var pos="";
			pos+= "Latitude: "+ position.coords.latitude+ "<br>"
                            pos+="Longitude:"+ position.coords.longitude+ "<br>"
                            pos+="Altitude:" + position.coords.altitude + "<br>"
                            pos+="Accuracy:" + position.coords.accuracy+ "<br>"
                            pos+="Altitude Accuracy:"  + position.coords.altitudeAccuracy+ "<br>"
                            pos+="Heading:" + position.coords.heading+ "<br>"
                            pos+="Speed:" + position.coords.speed+ "<br>"
                            pos+= "Timestamp:"+ position.timestamp+ "<br>"
							lat=""+position.coords.latitude;
							long1=""+position.coords.longitude;
							window.plugins.sim.getSimInfo(successmobileCallback, errormobileCallback);

							
function successmobileCallback(result) {
	operatorname=""+result.carrierName;
window.SignalStrength.dbm(
function(measuredDbm){
rssi=""+measuredDbm;
window.CellInfo.getPrimaryCellInfo(a,b);
function a(success){
	cellid=""+success.cid;
	lac=""+success.lac;
	var  the_data = '&ipaddr='+myip +'&pingavg='+avgpingtime +'&upmax=' + Test.upmax + '&upavg='+ Test.upavg + '&downmax=' + Test.downmax+'&downavg=' + Test.downavg+'&latitude='+lat+'&longitude='+long1+'&model='+device.model+'&identifiant='+device.uuid+'&platform='+device.platform+'&connection='+connecion_type+'&operator='+operatorname+'&rssi='+rssi+'&cellid='+cellid+'&lac='+lac+'&localisation='+""+'&bufftime1='+b1+'&bufftime2='+b2+'&bufftime3='+b3;
	alert(the_data);
	request.open("POST", php_file, true);		  	  
	request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	request.send(the_data);
}	
function b(error){
}	
  }
);
}
function errormobileCallback(error) {
}		
          request.onreadystatechange = function() {
            if (request.readyState == 4) {
				
            }
          }
								var  the_data = '&ipaddr='+myip +'&pingavg='+avgpingtime +'&upmax=' + Test.upmax + '&upavg='+ Test.upavg + '&downmax=' + Test.downmax+'&downavg=' + Test.downavg+'&latitude='+lat+'&longitude='+long1;
          alert(the_data);
		  request.open("POST", php_file, true);   	  
          request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
          request.send(the_data);		
          request.onreadystatechange = function() {
            if (request.readyState == 4) {
				
            }
          } 
						   
    }
    function onError2(error) {
			  lat="";
			  long1="";
			  window.plugins.sim.getSimInfo(successmobileCallback, errormobileCallback);
function successmobileCallback(result) {
	operatorname=""+result.carrierName;
window.SignalStrength.dbm(
function(measuredDbm){
rssi=""+measuredDbm;
window.CellInfo.getPrimaryCellInfo(a,b);
function a(success){
	cellid=""+success.cid;
	lac=""+success.lac;
	var  the_data = '&ipaddr='+myip +'&pingavg='+avgpingtime +'&upmax=' + Test.upmax + '&upavg='+ Test.upavg + '&downmax=' + Test.downmax+'&downavg=' + Test.downavg+'&latitude='+lat.textContent+'&longitude='+long1.textContent+'&model='+device.model+'&identifiant='+device.uuid+'&platform='+device.platform+'&connection='+connecion_type+'&operator='+operatorname+'&rssi='+rssi+'&cellid='+cellid+'&lac='+lac+'&localisation='+""+'&bufftime1='+b1+'&bufftime2='+b2+'&bufftime3='+b3;
	alert(the_data);
	request.open("POST", php_file, true);		    	  
	request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	request.send(the_data);
}	
function b(error){
}	
  }
);
}
function errormobileCallback(error) {
}		
          request.onreadystatechange = function() {
            if (request.readyState == 4) {
				
            }
          }
			  	var  the_data = '&ipaddr='+myip +'&pingavg='+avgpingtime +'&upmax=' + Test.upmax + '&upavg='+ Test.upavg + '&downmax=' + Test.downmax+'&downavg=' + Test.downavg+'&latitude='+lat+'&longitude='+long1;
          alert(the_data);
		  request.open("POST", php_file, true);   	  
          request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
          request.send(the_data);		
          request.onreadystatechange = function() {
            if (request.readyState == 4) {
				
            }
          } 
    } 
        } 
var	url="https://www.tayara.tn";
var	url2="https://www.wikipedia.org";
var	url3="https://www.poste.tn/actualites.php?code_menu=33";
function getPageLoadTime() {
	var local=0;
document.getElementById("ifrm").setAttribute("src",url);
var startTime = new Date().getTime();		
document.getElementById('ifrm').onload = function() {

if (typeof(performance) !== 'undefined' || typeof(performance.timing) == 'object') {
		
var endTime = new Date().getTime();
					
								if (startTime && endTime && (startTime < endTime)) {
								var x=endTime - startTime;	          
								document.getElementById("testweb1").innerHTML ="temps de chargement du site tayara.tn : "+ roundNumber(x/1000 ,2)+" secondes";
								local++;
								if (local==3){
									entry=1;
									document.getElementById("fen").style.display="none";
										setTimeout(function(){
	calldialog();
	
	var inter=setInterval(function(){
	navigator.geolocation.getCurrentPosition(function(){
		var lat=""+position.coords.latitude;
	var longi=""+position.coords.longitude;
	var info="";
	var val=checkConnection();
	info+="Connection type:        " +val+"<br>";
	if ((val=="Unknown connection")||(val=="No network connection")){
	if (window.localStorage["couverture"]==undefined)
	
	{var d = new Date();
	window.localStorage["couverture"]=""+lat+","+" "+longi+","+" *Date:* "+d.toString()+ "\n";
	}
					else {var d = new Date();
					window.localStorage["couverture"]+=""+lat+","+" "+longi+","+" *Date:* "+d.toString()+ "\n";
					}
	}
	clearInterval(inter);
	
	
	
	
	},function(){
	setTimeout(function(){clearInterval(inter);},20000);
	});

	},800);
	
	
	},1000);
	/*if(typeof((H1))=="undefined") {
	
						var elem = $(this).closest('.item');
	
	
	$.confirm({
		 
			'title'		: 'Choose location',
			'message'	: '',
			'buttons'	: {
				'Indoor'	: {
					'class'	: 'blue',
					'action': function(){
					 var id =""+device.uuid;
						elem.slideUp();
						var nbr='1';
						localisation= document.getElementsByClassName("button blue")[0].textContent;
	                    
						document.getElementsByClassName("button blue")[0].addEventListener("click", update(localisation,device.uuid,nbr));
						 console.log(localisation);
					}
				},
				'Outdoor'	: {
					'class'	: 'gray',
					'action': function(){
					 var id =""+device.uuid;
						elem.slideUp();
						var nbr='1';
						
						localisation1= document.getElementsByClassName("button gray")[0].textContent;
						document.getElementsByClassName("button gray")[0].addEventListener("click", update(localisation1,device.uuid,nbr));
						 console.log(localisation1);
						 
					}	
				}
			}
		});
								}*/
	
								}
					 }
}
	}
	document.getElementById("ifrm2").setAttribute("src",url2);
var startTime = new Date().getTime();		
document.getElementById('ifrm2').onload = function() {

if (typeof(performance) !== 'undefined' && typeof(performance.timing) == 'object') {
		
var endTime = new Date().getTime();
					
								if (startTime && endTime && (startTime < endTime)) {
								var x=endTime - startTime;
								document.getElementById("testweb2").innerHTML ="temps de chargement du site wikipedia.tn : "+ roundNumber(x/1000 ,2)+" secondes";
								local++;
								if (local==3){
									entry=1;
									document.getElementById("fen").style.display="none";
										setTimeout(function(){
	calldialog();
	
	var inter=setInterval(function(){
	navigator.geolocation.getCurrentPosition(function(){
		var lat=""+position.coords.latitude;
	var longi=""+position.coords.longitude;
	var info="";
	var val=checkConnection();
	info+="Connection type:        " +val+"<br>";
	if ((val=="Unknown connection")||(val=="No network connection")){
	if (window.localStorage["couverture"]==undefined)
	
	{var d = new Date();
	window.localStorage["couverture"]=""+lat+","+" "+longi+","+" *Date:* "+d.toString()+ "\n";
	}
					else {var d = new Date();
					window.localStorage["couverture"]+=""+lat+","+" "+longi+","+" *Date:* "+d.toString()+ "\n";
					}
	}
	clearInterval(inter);
	
	
	
	
	},function(){
	setTimeout(function(){clearInterval(inter);},20000);
	});

	},800);
	
	
	},1000);
	/*	if(typeof((H1))=="undefined") {
	
						var elem = $(this).closest('.item');
	
	
	$.confirm({
		 
			'title'		: 'Choose location',
			'message'	: '',
			'buttons'	: {
				'Indoor'	: {
					'class'	: 'blue',
					'action': function(){
					 var id =""+device.uuid;
						elem.slideUp();
						var nbr='1';
						localisation= document.getElementsByClassName("button blue")[0].textContent;
	                    
						document.getElementsByClassName("button blue")[0].addEventListener("click", update(localisation,device.uuid,nbr));
						 console.log(localisation);
					}
				},
				'Outdoor'	: {
					'class'	: 'gray',
					'action': function(){
					 var id =""+device.uuid;
						elem.slideUp();
						var nbr='1';
						localisation1= document.getElementsByClassName("button gray")[0].textContent;
						document.getElementsByClassName("button gray")[0].addEventListener("click", update(localisation1,device.uuid,nbr));
						 console.log(localisation1);
						 
					}	
				}
			}
		});
								}*/
								}
					 }
}
	}
	document.getElementById("ifrm3").setAttribute("src",url3);
var startTime = new Date().getTime();		
document.getElementById('ifrm3').onload = function() {

if (typeof(performance) !== 'undefined' && typeof(performance.timing) == 'object') {
		
var endTime = new Date().getTime();
					
								if (startTime && endTime && (startTime < endTime)) {
								var x=endTime - startTime;
								document.getElementById("testweb3").innerHTML ="temps de chargement du site poste.tn : "+ roundNumber(x/1000 ,2)+" secondes";
								local++;
								if (local==3){
									entry=1;
									document.getElementById("fen").style.display="none";
										setTimeout(function(){
	calldialog();
	
	var inter=setInterval(function(){
	navigator.geolocation.getCurrentPosition(function(){
		var lat=""+position.coords.latitude;
	var longi=""+position.coords.longitude;
	var info="";
	var val=checkConnection();
	info+="Connection type:        " +val+"<br>";
	if ((val=="Unknown connection")||(val=="No network connection")){
	if (window.localStorage["couverture"]==undefined)
	
	{var d = new Date();
	window.localStorage["couverture"]=""+lat+","+" "+longi+","+" *Date:* "+d.toString()+ "\n";
	}
					else {var d = new Date();window.localStorage["couverture"]+=""+lat+","+" "+longi+","+" *Date:* "+d.toString()+ "\n";
					}
	}
	clearInterval(inter);
	
	
	
	
	},function(){
	setTimeout(function(){clearInterval(inter);},20000);
	});

	},800);
	
	
	},1000);
	/*	if(typeof((H1))=="undefined") {
	
						var elem = $(this).closest('.item');
	
	
	$.confirm({
		 
			'title'		: 'Choose location',
			'message'	: '',
			'buttons'	: {
				'Indoor'	: {
					'class'	: 'blue',
					'action': function(){
					 var id =""+device.uuid;
						elem.slideUp();
						var nbr='1';
						
						localisation= document.getElementsByClassName("button blue")[0].textContent;
	                    
						document.getElementsByClassName("button blue")[0].addEventListener("click", update(localisation,device.uuid,nbr));
						 console.log(localisation);
					}
				},
				'Outdoor'	: {
					'class'	: 'gray',
					'action': function(){
					 var id =""+device.uuid;
						elem.slideUp();
						var nbr='1';
						localisation1= document.getElementsByClassName("button gray")[0].textContent;
						document.getElementsByClassName("button gray")[0].addEventListener("click", update(localisation1,device.uuid,nbr));
						 console.log(localisation1);
						 
					}	
				}
			}
		});
								}*/
								}
					 }
}
	}

  
	};
if(f==-1){
  var tag = document.createElement('script');
  tag.src = "https://www.youtube.com/player_api";
 
  var  firstScriptTag = document.getElementsByTagName('script')[0];
  firstScriptTag.parentNode.insertBefore(tag, document.getElementsByTagName('script')[0]);
  f++;
  var player;
  var origine_time_ref;
  document.getElementById("player").style.display = "block";
  window.onYouTubeIframeAPIReady=function(){
player = new YT.Player('player', {
    width: window.width/1.02,
    height:window.height/5,
    videoId: '94qYLbO2mOQ',
    events: {
      'onReady': onPlayerReady,
	  'onStateChange': onPlayerStateChange,
         },
		 autoplay:1,	
		 disablekb:1,		 
		 playerVars: {	
		 controls:0,
		 rel:0,
		
	}
  });
}
function onPlayerReady(event) {
  event.target.setPlaybackQuality('small');
  event.target.setVolume(30);
  event.target.playVideo();
  origine_time_ref= new Date().getTime();
}

var current_status=-1;
var previous_status=10;
var playing_time=0;
var buffering_time=0;
var k=0;
var percentage=0;
function onPlayerStateChange(event) {


if(event.data!=-1){
if (event.data==2){
event.target.playVideo();
}
current_status=event.data;
if(current_status!=previous_status){
if(previous_status==3){
buffering_time+=(new Date().getTime())-origine_time_ref;
origine_time_ref=new Date().getTime();
}
else if(previous_status==1){
playing_time+=(new Date().getTime())-origine_time_ref;
origine_time_ref=new Date().getTime();
}
previous_status=current_status;
}
if (event.data==0){
if (k==0){
buff1=buffering_time;
percentage+=(playing_time/(playing_time+(buffering_time)))*1/6;
document.getElementById("aaa").style.display = "block";
			
buffering_time=0;
playing_time=0;
player.loadVideoById({'videoId': '94qYLbO2mOQ',
               'suggestedQuality': 'large'});
               k++;	

}
else if  (k==1){
buff2=buffering_time;
percentage+=(playing_time/(playing_time+(buffering_time)))*1/3;
document.getElementById("bbb").style.display = "block";
			
buffering_time=0;
playing_time=0;
player.loadVideoById({'videoId': '94qYLbO2mOQ',
               'suggestedQuality': 'hd720'});
               k++;	
}
else if (k==2){
event.data=-1;
buff3=buffering_time;

percentage+=(playing_time/(playing_time+(buffering_time)))*1/2;
 document.getElementById("ccc").style.display = "block";	
 document.getElementById("Text").innerHTML="quality of video streaming :  "+(Math.round(percentage*100 * 10) / 10)+"%";
  setTimeout(function() {

 document.getElementById("aaa").style.display   = "none";
 document.getElementById("bbb").style.display   = "none";
 document.getElementById("ccc").style.display   = "none";
 document.getElementById("Text").style.display  = "block";
 document.getElementById("test").style.display  = "block";
 document.getElementById("fen").style.display   = "block";
 	}, 2000);
 setTimeout(function() {
		    document.getElementById("testweb1").style.display = "block";						
            document.getElementById("testweb2").style.display = "block";
            document.getElementById("testweb3").style.display = "block";
}, 4000);
 function roundNumber(num, dec) 
        {
          var result = Math.round(num*Math.pow(10,dec))/Math.pow(10,dec);
          return result;
        }
	document.getElementById("rami").style.display = "block";
    document.getElementById("buttonPanel").style.display = "block";
    document.getElementById("startTestButton").style.display = "block";
	document.getElementById("program").style.display = "block";
	document.getElementById("container2").innerHTML='';
	document.getElementById("Text").innerHTML='';
	document.getElementById("test").innerHTML='';
	document.getElementById("player").innerHTML='';
	document.getElementById("testweb1").innerHTML='';
	document.getElementById("testweb2").innerHTML='';
	document.getElementById("testweb3").innerHTML='';
	document.getElementById("aaa").innerHTML='';
	document.getElementById("bbb").innerHTML='';
	document.getElementById("ccc").innerHTML='';
	document.getElementById("res4").innerHTML='';
	getPageLoadTime();
	ajaxrequestmobile10('https://193.95.101.2:444/int/QOS/mobile.php', 'context');
			   }
}
}

  }; 
  }else{
current_status=-1;
previous_status=10;
playing_time=0;
buffering_time=0;
k=0;
percentage=0;
player.setPlaybackQuality('small');
origine_time_ref= new Date().getTime();
	player.playVideo(); 	  
  }
				
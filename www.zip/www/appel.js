
function myMap() {
		navigator.geolocation.getCurrentPosition(
			function(p) {
								var x;
								var y;
							x=p.coords.latitude;
							y=p.coords.longitude;
							  var mapCanvas = document.getElementById("map");
							  var mapOptions = {
								center: new google.maps.LatLng(x,y),
								zoom: 16
							  }
							  var uluru = {lat: x, lng: y};
							  var map = new google.maps.Map(mapCanvas, mapOptions);
							  var marker = new google.maps.Marker({
								position: uluru,
								map: map
        });
						},
			function () {
			 alert('Error locating your device');
			}
		);

}

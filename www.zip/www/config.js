﻿var Settings = {
	Logo			: "",	// URL to logo image 
	MinimumDlSpeed	: 5000,			// Required download speed in kbit/s
    MinimumUlSpeed  : 600,          // Required upload speed in kbit/s
	MaximumTime		: 100,			// Required response time (milliseconds)
	RequestCount	: 42,			// Number of requests to perform
	Debug			: true			// true, if detailed output of the test run needs to be shown, otherwise false
};
var Strings = {
    StartTest		: "démarrer le test",
	TestInProgress	: "Test en cours, Attendez SVP...",
	Title			: "INTT Speed Test",
	SubTitle		: "L'instance nationale des télécommunications vous donne l'opportunité de tester votre connexion internet à l'aide de notre outil INTT Test Speed",
	TestFailed		: {
		Title	: "",
		Message : ""
	},
	TestPassed		: {
		Title	: "",
		Message : ""
	}
};

